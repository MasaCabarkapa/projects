﻿using System.ComponentModel.DataAnnotations;

namespace eStore.Models
{
    public class Product : BaseClass
    {
        [Required]
        public string Name { get; set; } = String.Empty;

        [Required]
        public double Price { get; set; }
        [Required]
        public int Amount { get; set; }
        [Required]
        public string Color { get; set; } = String.Empty;
        [Required]
        public string Brand { get; set; } = String.Empty;
        [Required]
        public double MaxSpeed { get; set; }
        [Required]
        public double Reach { get; set; }
        [Required]
        public int CarryingCapacity { get; set; }

        public int SellerId { get; set; }
        public virtual User? Seller { get; set; }

        public virtual List<OrderItem>? OrderItems { get; set; }
    }
}
