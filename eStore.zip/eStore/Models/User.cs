﻿using System.ComponentModel.DataAnnotations;

namespace eStore.Models
{
    public enum UserType { Admin = 0, Customer = 1}

    public class User : BaseClass
    {
        [Required, MaxLength(100), RegularExpression("[a-zA-Z0-9]+")]
        public string Username { get; set; } = String.Empty;
        [Required, MaxLength(300)]
        public string Password { get; set; } = String.Empty;
        [Required, MaxLength(100), EmailAddress]
        public string Email { get; set; } = String.Empty;
        [Required, MaxLength(100)]
        public string Name { get; set; } = String.Empty;
        [Required, MaxLength(100)]
        public string Surname { get; set; } = String.Empty;
        [Required, MaxLength(200)]
        public string Address { get; set; } = String.Empty;
        [Required, MaxLength(100)]
        public string PhoneNumber { get; set; } = String.Empty;
        [Required]
        public UserType Type { get; set; }
        public virtual List<Product>? Products { get; set; }
    }
}
