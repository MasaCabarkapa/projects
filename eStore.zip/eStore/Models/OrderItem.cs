﻿using System.ComponentModel.DataAnnotations;

namespace eStore.Models
{
    public class OrderItem : BaseClass
    {
        [Required]
        public int Amount { get; set; }
        [Required]
        public int ProductId { get; set; }
        [Required]
        public int OrderId { get; set; }
        [Required]
        public virtual Order? Order { get; set; }
        [Required]
        public virtual Product? Product { get; set; }
    }
}
