﻿using System.ComponentModel.DataAnnotations;

namespace eStore.Models
{
    public class Order : BaseClass
    {
        [Required]
        public string Status { get; set; } = String.Empty;
        [Required]
        public DateTime OrderTime { get; set; }
        public string Comment { get; set; } = String.Empty;

        [Required]
        public DateTime DeliveryTime { get; set; }
        [Required]
        public double OrderPrice { get; set; }
        public int BuyerId { get; set; }
        public virtual User? Buyer { get; set; }

        public virtual List<OrderItem> Items { get; set; }
    }
}
