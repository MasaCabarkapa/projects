﻿namespace eStore.Models
{
    public class BaseClass
    {
        public int Id { get; set; }
    }
}
