﻿using eStore.Models;
using System.Linq.Expressions;

namespace eStore.Interfaces
{
    public interface IRepository<T> where T : BaseClass
    {
        Task<IList<T>> GetAll();
        Task<T> GetById(int id);
        Task Insert(T entity);
        void Update(T entity);
        void Delete(T entity);
        Task Save();
    }
}
