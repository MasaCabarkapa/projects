﻿using eStore.DTOs;

namespace eStore.Interfaces
{
    public interface IProfileService
    {
        Task<UserDTO> GetProfileDetails(int userId);
        Task ChangeProfileData(ChangeProfileDTO changeProfileDTO, int userId);
        Task ChangePassword(ChangePasswordDTO changePasswordDTO, int userId);
    }
}
