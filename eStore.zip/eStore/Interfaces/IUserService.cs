﻿using eStore.DTOs;
using Microsoft.AspNetCore.Mvc;

namespace eStore.Interfaces
{
    public interface IUserService
    {
        Task<List<ProductDTO>> GetProducts();

        Task CreateOrder(CreateOrderDTO createOrder, int userId);
        Task CancelOrder(int userId, int id);

        Task<List<OrderDTO>> GetMyOrders(int userId);

        Task<List<OrderItemDTO>> GetOrderDetails(int orderId, int userId);
        Task<List<ProductDTO>> GetFilteredProducts(int? Price, string? Color, string? Brand, double? Reach, double? MaxSpeed, int? CarryingCapacity);

    }
}
