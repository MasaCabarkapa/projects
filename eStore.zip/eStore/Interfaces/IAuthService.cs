﻿using eStore.DTOs;

namespace eStore.Interfaces
{
    public interface IAuthService
    {
        public Task Register(RegisterDTO registerDTO);

        public Task<string> Login(LoginDTO loginDTO);
    }
}
