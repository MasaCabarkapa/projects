﻿using eStore.DTOs;

namespace eStore.Interfaces
{
    public interface IAdminService
    {
        Task<List<ProductDTO>> GetProducts(int userId);
        Task<ProductDTO> GetProduct(int id, int userId);
        Task DeleteProduct(int id, int userId);
        Task UpdateProduct(int id, ProductDTO product, int userId);
        Task AddProduct(CreateProductDTO product, int userId);
        Task<List<OrderDTO>> GetOrdersWaitingForApproval();
        Task ApproveOrder(int OrderId);
        Task AddExistingProduct(int id, int amount);
        Task RemoveProduct(int productId, int amount);
    }
}
