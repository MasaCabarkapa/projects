﻿using System.ComponentModel.DataAnnotations;

namespace eStore.DTOs
{
    public class ChangePasswordDTO
    {
        [Required, MaxLength(100)]
        public string OldPassword { get; set; } = String.Empty;
        [Required, MaxLength(100)]
        public string NewPassword { get; set; } = String.Empty;
    }
}
