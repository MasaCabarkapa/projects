﻿using eStore.Models;
using System.ComponentModel.DataAnnotations;

namespace eStore.DTOs
{
    public class UserDTO
    {
        public string Username { get; set; } = String.Empty;
        public string Email { get; set; } = String.Empty;
        public string Name { get; set; } = String.Empty;
        public string Surname { get; set; } = String.Empty;
        public string Address { get; set; } = String.Empty;
        public string PhoneNumber { get; set; } = String.Empty;
        public UserType Type { get; set; }
    }
}
