﻿using eStore.Models;
using System.ComponentModel.DataAnnotations;

namespace eStore.DTOs
{
    public class ChangeProfileDTO
    {
        [Required, MaxLength(100), RegularExpression("[a-zA-Z0-9]+")]
        public string Username { get; set; } = String.Empty;
        [Required, MaxLength(100), EmailAddress]
        public string Email { get; set; } = String.Empty;
        [Required, MaxLength(100)]
        public string Name { get; set; } = String.Empty;
        [Required, MaxLength(100)]
        public string Surname { get; set; } = String.Empty;
        [Required, MaxLength(200)]
        public string Address { get; set; } = String.Empty;
        [Required, MaxLength(100)]
        public string PhoneNumber { get; set; } = String.Empty;
    }
}
