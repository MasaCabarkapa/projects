﻿namespace eStore.DTOs
{
    public class OrderDTO
    {
        public int Id { get; set; }
        public string DeliveryAddress { get; set; } = String.Empty;
        public string Comment { get; set; } = String.Empty;
        public DateTime OrderTime { get; set; }
        public DateTime DeliveryTime { get; set; }
        public double OrderPrice { get; set; }

        private string _status = String.Empty;
        public string Status
        {
            get
            {
                if (_status == "Approved" && DeliveryTime < DateTime.Now)
                {
                    return "Delivered";
                }
                return _status;
            }
            set
            {
                _status = value;
            }
        }
    }
}
