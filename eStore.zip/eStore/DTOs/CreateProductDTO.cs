﻿using System.ComponentModel.DataAnnotations;

namespace eStore.DTOs
{
    public class CreateProductDTO
    {
        [Required, MaxLength(100)]
        public string Name { get; set; } = String.Empty;
        [Required, Range(0, double.MaxValue)]
        public double Price { get; set; }
        [Required, Range(1, int.MaxValue)]
        public int Amount { get; set; }
        [Required]
        public string Color { get; set; } = String.Empty;
        [Required]
        public string Brand { get; set; } = String.Empty;
        [Required]
        public double MaxSpeed { get; set; }
        [Required]
        public double Reach { get; set; }
        [Required]
        public int CarryingCapacity { get; set; }
    }
}
