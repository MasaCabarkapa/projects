﻿namespace eStore.DTOs
{
    public class SellerDTO
    {
        public string? Username { get; set; }
        public string? Email { get; set; }
    }
}
