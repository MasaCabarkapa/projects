﻿using System.ComponentModel.DataAnnotations;

namespace eStore.DTOs
{
    public class CreateOrderDTO
    {
        public string? Comment { get; set; }
        public List<CreateOrderItemDTO>? Items { get; set; }
    }
}
