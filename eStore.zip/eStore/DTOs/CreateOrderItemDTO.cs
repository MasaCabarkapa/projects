﻿using System.ComponentModel.DataAnnotations;

namespace eStore.DTOs
{
    public class CreateOrderItemDTO
    {
        [Required, Range(0, int.MaxValue)]
        public int Amount { get; set; }
        [Required, Range(0, int.MaxValue)]
        public int ProductId { get; set; }
    }
}
