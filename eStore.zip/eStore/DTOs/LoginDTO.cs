﻿using System.ComponentModel.DataAnnotations;

namespace eStore.DTOs
{
    public class LoginDTO
    {
        [Required, MaxLength(100)]
        public string Email { get; set; } = String.Empty;
        [Required, MaxLength(100)]
        public string Password { get; set; } = String.Empty;
    }
}
