﻿using System.ComponentModel.DataAnnotations;

namespace eStore.DTOs
{
    public class AddExistingProductDTO
    {
        [Required]
        public int Id { get; set; }
        [Required]
        public int Amount { get; set; }
    }
}
