﻿namespace eStore.DTOs
{
    public class OrderItemDTO : CreateOrderItemDTO
    {
        public string Name { get; set; } = String.Empty;
        public double Price { get; set; }
    }
}
