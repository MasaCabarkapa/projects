﻿using eStore.Interfaces;
using eStore.Models;
using eStore.Settings;

namespace eStore.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly StoreDbContext _context;

        public UnitOfWork(StoreDbContext context, IRepository<User> users, IRepository<Product> products, IRepository<Order> orders)
        {
            _context = context;
            Users = users;
            Products = products;
            Orders = orders;
        }

        public IRepository<User>? Users { get; }
        public IRepository<Product>? Products { get; }
        public IRepository<Order>? Orders { get; }



        public async Task Save()
        {
            await _context.SaveChangesAsync();
        }
    }
}
