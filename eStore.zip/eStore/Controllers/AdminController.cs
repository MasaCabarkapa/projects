﻿using eStore.DTOs;
using eStore.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace eStore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IAdminService _adminService;

        public AdminController(IAdminService adminService)
        {
            _adminService = adminService;
        }

        [HttpGet("products")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetProducts()
        {
            if (!int.TryParse(User.Claims.First(c => c.Type == "Id").Value, out int id))
                throw new Exception("Bad ID. Logout and login.");
            var products = await _adminService.GetProducts(id);
            return Ok(products);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("products")]
        public async Task<IActionResult> AddProduct([FromForm] CreateProductDTO productDTO)
        {
            if (!int.TryParse(User.Claims.First(c => c.Type == "Id").Value, out int userId))
                throw new Exception("Bad ID. Logout and login.");

            await _adminService.AddProduct(productDTO, userId);
            return Ok();
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("product")]
        public async Task<IActionResult> AddExistingProduct([FromForm] AddExistingProductDTO productDTO)
        {
            if (!int.TryParse(User.Claims.First(c => c.Type == "Id").Value, out int userId))
                throw new Exception("Bad ID. Logout and login.");

            await _adminService.AddExistingProduct(productDTO.Id, productDTO.Amount);
            return Ok();
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("orders-to-approve")]
        public async Task<IActionResult> GetOrdersWaitingForApproval()
        {
            if (!int.TryParse(User.Claims.First(c => c.Type == "Id").Value, out int userId))
                throw new Exception("Bad ID. Logout and login.");

            var orders = await _adminService.GetOrdersWaitingForApproval();
            return Ok(orders);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("approve")]
        public async Task<IActionResult> ApproveOrder(int id)
        {
            if (!int.TryParse(User.Claims.First(c => c.Type == "Id").Value, out int userId))
                throw new Exception("Bad ID. Logout and login.");

            await _adminService.ApproveOrder(id);
            return Ok();
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("remove-product")]
        public async Task<IActionResult> RemoveProduct(int id, int amount)
        {
            if (!int.TryParse(User.Claims.First(c => c.Type == "Id").Value, out int userId))
                throw new Exception("Bad ID. Logout and login.");

            await _adminService.RemoveProduct(id, amount);
            return Ok();
        }

    }
}
