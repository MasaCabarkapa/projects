﻿using eStore.DTOs;
using eStore.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace eStore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProfileController : ControllerBase
    {
        private readonly IProfileService _profileService;

        public ProfileController(IProfileService profileService)
        {
            _profileService = profileService;
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetProfileDetails()
        {
            if (!int.TryParse(User.Claims.First(c => c.Type == "Id").Value, out int id))
                throw new Exception("Bad ID. Logout and login.");
            var user = await _profileService.GetProfileDetails(id);
            return Ok(user);

        }

        [HttpPatch]
        [Authorize]
        public async Task<IActionResult> UpdateProfileDetails(ChangeProfileDTO changeProfileDTO)
        {
            if (!int.TryParse(User.Claims.First(c => c.Type == "Id").Value, out int id))
                throw new Exception("Bad ID. Logout and login.");
            await _profileService.ChangeProfileData(changeProfileDTO, id);
            return Ok();

        }

        [HttpPatch("password")]
        [Authorize]
        public async Task<IActionResult> ChangePassword(ChangePasswordDTO changePasswordDTO)
        {
            if (!int.TryParse(User.Claims.First(c => c.Type == "Id").Value, out int id))
                throw new Exception("Bad ID. Logout and login.");
            await _profileService.ChangePassword(changePasswordDTO, id);
            return Ok();

        }

    }
}
