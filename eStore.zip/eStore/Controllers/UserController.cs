﻿using eStore.DTOs;
using eStore.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace eStore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }



        [Authorize(Roles = "Customer")]
        [HttpGet("products")]
        public async Task<IActionResult> GetProducts()
        {
            var products = await _userService.GetProducts();
            return Ok(products);
        }

        [Authorize(Roles = "Customer")]
        [HttpPost("order")]
        public async Task<IActionResult> CreateOrder(CreateOrderDTO createOrder)
        {
            if (!int.TryParse(User.Claims.First(c => c.Type == "Id").Value, out int id))
                throw new Exception("Bad ID. Logout and login.");

            await _userService.CreateOrder(createOrder, id);
            return Ok();
        }

        [Authorize(Roles = "Customer")]
        [HttpGet("orders")]
        public async Task<IActionResult> GetPreviousOrders()
        {
            if (!int.TryParse(User.Claims.First(c => c.Type == "Id").Value, out int id))
                throw new Exception("Bad ID. Logout and login.");
            var orders = await _userService.GetMyOrders(id);
            return Ok(orders);
        }

        [Authorize(Roles = "Customer")]
        [HttpGet("orders/{id}")]
        public async Task<IActionResult> GetOrderDetails(int id)
        {
            if (!int.TryParse(User.Claims.First(c => c.Type == "Id").Value, out int userId))
                throw new Exception("Bad ID. Logout and login.");
            var orders = await _userService.GetOrderDetails(id, userId);
            return Ok(orders);
        }

        [Authorize(Roles = "Customer")]
        [HttpPatch("cancel-order/{id}")]
        public async Task<IActionResult> CancelOrder(int id)
        {
            if (!int.TryParse(User.Claims.First(c => c.Type == "Id").Value, out int userId))
                throw new Exception("Bad ID. Logout and login.");

            await _userService.CancelOrder(userId, id);
            return Ok();
        }

        [Authorize(Roles = "Customer")]
        [HttpGet("filter-products")]
        public async Task<IActionResult> GetFilteredData([FromQuery] int? Price, [FromQuery] string? Color, [FromQuery] string? Brand, [FromQuery] double? Reach, [FromQuery] double? MaxSpeed, [FromQuery] int? CarryingCapacity)
        {
            var products = await _userService.GetFilteredProducts(Price, Color, Brand, Reach, MaxSpeed, CarryingCapacity);
            return Ok(products);
        }

    }
}
