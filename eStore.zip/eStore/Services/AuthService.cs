﻿using AutoMapper;
using eStore.DTOs;
using eStore.Interfaces;
using eStore.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using BC = BCrypt.Net;


namespace eStore.Services
{
    public class AuthService : IAuthService
    {
        private IConfiguration _configuration;
        private IUnitOfWork _unitOfWork;
        private IMapper _mapper;

        public AuthService(IConfiguration configuration, IUnitOfWork unitOfWork, IMapper mapper)
        {
            _configuration = configuration;
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task Register(RegisterDTO registerDTO)
        {
            var user = _mapper.Map<User>(registerDTO);
            await _unitOfWork.Users.Insert(user);
            await _unitOfWork.Save();
        }

        private string GetToken(User user)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!));
            var claims = new[]
            {
                new Claim(ClaimTypes.Name, user.Username!),
                new Claim(ClaimTypes.Role, user.Type.ToString()),
                new Claim("Id", user.Id.ToString()),
                new Claim("Email", user.Email!),
            };
            var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                claims: claims,
                expires: DateTime.Now.AddDays(1),
                signingCredentials: signIn);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public async Task<string> Login(LoginDTO loginDTO)
        {
            var users = await _unitOfWork.Users.GetAll();
            var user = users
                .Where(u => u.Email.Equals(loginDTO.Email))
                .FirstOrDefault();
            if (user == null)
                throw new Exception($"Incorrect email. Try again.");

            if (!BC.BCrypt.Verify(loginDTO.Password, user.Password))
                throw new Exception("Invalid password");

            //if (user.Type == UserType.Seller)
            //{
            //    if (user.VerificationStatus == VerificationStatus.Waiting)
            //        throw new Exception("You are not verified. Wait to be verified by administrators.");
            //    if (user.VerificationStatus == VerificationStatus.Declined)
            //        throw new Exception("You were declined by administrators. Contact to see why.");
            //}

            return GetToken(user);
        }
    }
}
