﻿using AutoMapper;
using eStore.DTOs;
using eStore.Interfaces;
using eStore.Models;

namespace eStore.Services
{
    public class AdminService : IAdminService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public AdminService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }
        private async Task<User> ValidateUser(int userId)
        {
            var user = await _unitOfWork.Users.GetById(userId);
            if (user == null)
                throw new Exception("Error with id in token. Logout and login again");
            return user;
        }

        public async Task AddProduct(CreateProductDTO product, int userId)
        {
            await ValidateUser(userId);
            var prod = _mapper.Map<Product>(product);
            prod.SellerId = userId;
            await _unitOfWork.Products.Insert(prod);
            await _unitOfWork.Save();

        }

        public async Task DeleteProduct(int id, int userId)
        {
            await ValidateUser(userId);
            var product = await _unitOfWork.Products.GetById(id);
            if(product == null)
            {
                throw new Exception("This product does not exist");
            }

            _unitOfWork.Products.Delete(product);
            await _unitOfWork.Save();

        }

        public async Task<ProductDTO> GetProduct(int id, int userId)
        {
            await ValidateUser(userId);
            var product = await _unitOfWork.Products.GetById(id);

            if (product == null)
            {
                throw new Exception("This product does not exist");
            }
            var productDto = _mapper.Map<ProductDTO>(product);
            return productDto;
        }

        public async Task<List<ProductDTO>> GetProducts(int userId)
        {
            await ValidateUser(userId);
            var products = await _unitOfWork.Products.GetAll();
            return _mapper.Map<List<ProductDTO>>(products.Where(p => p.SellerId == userId));
        }

        public async Task UpdateProduct(int id, ProductDTO product, int userId)
        {
            await ValidateUser(userId);
            var prod = await _unitOfWork.Products.GetById(id);

            if (prod == null || prod.SellerId != userId)
            {
                throw new Exception("This product does not exist");
            }
            prod.Name = product.Name;
            prod.Price = product.Price;
            prod.Amount = product.Amount;
            prod.Color = product.Color;
            prod.Brand = product.Brand;
            prod.MaxSpeed = product.MaxSpeed;
            prod.Reach = product.Reach;
            prod.CarryingCapacity = product.CarryingCapacity;
            prod.CarryingCapacity = product.CarryingCapacity;

        }

        public async Task<List<OrderDTO>> GetOrdersWaitingForApproval()
        {
            var orders = await _unitOfWork.Orders.GetAll();
            var userOrders = orders.Where(o => o.Status == "Waiting for approval");
            return _mapper.Map<List<OrderDTO>>(userOrders);
        }

        public async Task ApproveOrder(int OrderId)
        {
            var order = await _unitOfWork.Orders.GetById(OrderId);
            if(order == null)
            {
                throw new Exception($"Invalid id");
            }
            if (order.Status != "Waiting for approval")
            {
                throw new Exception($"Order is not waiting for approval");
            }
            var products = await _unitOfWork.Products.GetAll();
            if(order.Items.Any(item => item.Product.Amount < item.Amount))
            {
                throw new Exception($"This order can not be approved, not enough products");
            }
            order.Status = "Approved";
            foreach (var item in order.Items!)
            {
                var product = await _unitOfWork.Products.GetById(item.ProductId);
                if (product == null)
                    throw new Exception("Invalid Product ID.");

                if (item.Amount < 0)
                    throw new Exception($"Amount of {product.Name} can't be less than 0.");

                if (item.Amount > product.Amount)
                    throw new Exception($"System doesn't have enough {product.Name}.");

                product.Amount -= item.Amount;
                _unitOfWork.Products.Update(product);
            }
            order.DeliveryTime = DateTime.Now.AddHours(3).AddMinutes(new Random().Next(180));

            _unitOfWork.Orders.Update(order);
            await _unitOfWork.Save();
        }

        public async Task AddExistingProduct(int id, int amount)
        {
            var product = await _unitOfWork.Products.GetById(id);
            if (product == null)
            {
                throw new Exception("This product does not exist");
            }
            product.Amount += amount;
            _unitOfWork.Products.Update(product);
            await _unitOfWork.Save();
        }

        public async Task RemoveProduct(int productId, int amount)
        {
            var product = await _unitOfWork.Products.GetById(productId);
            if(product.Amount < amount)
            {
                throw new Exception($"There are only {product.Amount} items");
            }
            var orders = await _unitOfWork.Orders.GetAll();
            var ordersWithThisProduct = orders.Where(o => o.Status == "Approved" && o.DeliveryTime >= DateTime.Now && o.Items.Any(i => i.ProductId == productId)).ToList();

            var items = ordersWithThisProduct.SelectMany(o => o.Items).Where(item => item.ProductId == productId).ToList();
            int orderedProducts = 0;
            foreach (var item in items)
            {
                orderedProducts += item.Amount;
            }
            if((orderedProducts + amount) > product.Amount)
            {
                throw new Exception($"There are already {orderedProducts} ordered, you cant delete {amount}");
            }
            var ordersWithThisProductNotApproved = orders.Where(o => o.Status == "Waiting for approval" && o.Items.Any(i => i.Id == productId));
            foreach (var order in ordersWithThisProductNotApproved)
            {
                var orderProduct = order.Items.Where(item => item.Id == productId).FirstOrDefault();
                order.Items.Remove(orderProduct);
                order.OrderPrice -= orderProduct.Product.Price;
                _unitOfWork.Orders.Update(order);
            }
            product.Amount -= amount;
            _unitOfWork.Products.Update(product);
            await _unitOfWork.Save();
        }
    }
}
