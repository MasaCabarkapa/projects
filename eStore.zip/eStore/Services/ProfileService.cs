﻿using AutoMapper;
using eStore.DTOs;
using eStore.Interfaces;
using eStore.Models;
using BC = BCrypt.Net;

namespace eStore.Services
{
    public class ProfileService : IProfileService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public ProfileService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        private async Task<User> ValidateUser(int userId)
        {
            var user = await _unitOfWork.Users.GetById(userId);
            if (user == null)
                throw new Exception("Error with id in token. Logout and login again");
            return user;
        }
        public async Task<UserDTO> GetProfileDetails(int userId)
        {
            var user = await ValidateUser(userId);
            return _mapper.Map<UserDTO>(user);
        }

        public async Task ChangeProfileData(ChangeProfileDTO changeProfileDTO, int userId)
        {
            var user = await ValidateUser(userId);
            user.Username = changeProfileDTO.Username;
            user.Email = changeProfileDTO.Email;
            user.Name = changeProfileDTO.Name;
            user.Surname = changeProfileDTO.Surname;
            user.Address = changeProfileDTO.Address;
            user.PhoneNumber = changeProfileDTO.PhoneNumber;
            _unitOfWork.Users.Update(user);
            await _unitOfWork.Save();
        }

        public async Task ChangePassword(ChangePasswordDTO changePasswordDTO, int userId)
        {
            var user = await ValidateUser(userId);
            if (!BC.BCrypt.Verify(changePasswordDTO.OldPassword, user.Password))
                throw new Exception("Invalid password");

            user.Password = BC.BCrypt.HashPassword(changePasswordDTO.NewPassword);
            _unitOfWork.Users.Update(user);
            await _unitOfWork.Save();
        }
    }
}
