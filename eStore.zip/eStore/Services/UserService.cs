﻿using AutoMapper;
using eStore.DTOs;
using eStore.Interfaces;
using eStore.Models;
using eStore.Repository;
using System.Diagnostics;

namespace eStore.Services
{
    public class UserService : IUserService
    {

        readonly IUnitOfWork _unitOfWork;
        readonly IMapper _mapper;
        private readonly double deliveryFee = 99;

        public UserService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        private async Task<User> ValidateUser(int userId)
        {
            var user = await _unitOfWork.Users.GetById(userId);
            if (user == null)
                throw new Exception("Error with id in token. Logout and login again");
            return user;
        }
        public async Task CancelOrder(int userId, int id)
        {
            var user = await ValidateUser(userId);
            var order = await _unitOfWork.Orders.GetById(id);
            if (order.Status == "CANCELED")
            {
                throw new Exception($"Order is already canceled");
            }
            if (order.Status == "Approved" && order.DeliveryTime < DateTime.Now)
            {
                throw new Exception($"Order is already delivered");
            }
            if (order == null || order.BuyerId != userId)
                throw new Exception($"Order doesn't belong to user.");

            if (order.OrderTime.AddHours(1) < DateTime.Now)
                throw new Exception($"You can only cancel if it hasn't been an hour of order creation");

            order.Status = "CANCELED";
            foreach (var productItem in order.Items!)
            {
                var product = await _unitOfWork.Products.GetById(productItem.ProductId);
                if (product != null)
                {
                    product.Amount += productItem.Amount;
                    _unitOfWork.Products.Update(product);
                }
            }
            _unitOfWork.Orders.Update(order);
            await _unitOfWork.Save();
        }


        public async Task CreateOrder(CreateOrderDTO createOrder, int userId)
        {
            var user = await ValidateUser(userId);
            var order = _mapper.Map<Order>(createOrder);
            order.BuyerId = userId;
            order.Status = "Waiting for approval";
            order.OrderPrice = 0;
            order.OrderTime = DateTime.Now;
            var ids = new List<int>();

            foreach (var item in order.Items!)
            {
                var product = await _unitOfWork.Products.GetById(item.ProductId);
                if (product == null)
                    throw new Exception("Invalid Product ID.");

                if (item.Amount < 0)
                    throw new Exception($"Amount of {product.Name} can't be less than 0.");

                if (item.Amount > product.Amount)
                    throw new Exception($"System doesn't have enough {product.Name}.");
                order.OrderPrice += product.Price * item.Amount;
                if (!ids.Contains(product.SellerId))
                {
                    order.OrderPrice += deliveryFee;
                    ids.Add(product.SellerId);
                }
            }

            await _unitOfWork.Orders.Insert(order);
            await _unitOfWork.Save();

        }

        public async Task<List<OrderDTO>> GetMyOrders(int userId)
        {
            await ValidateUser(userId);
            var orders = await _unitOfWork.Orders.GetAll();
            var userOrders = orders.Where(o => o.BuyerId == userId);
            return _mapper.Map<List<OrderDTO>>(userOrders);
        }

        public async Task<List<ProductDTO>> GetProducts()
        {
            var products = await _unitOfWork.Products.GetAll();
            return _mapper.Map<List<ProductDTO>>(products);
        }

        public async Task<List<OrderItemDTO>> GetOrderDetails(int orderId, int userId)
        {
            await ValidateUser(userId);
            var order = await _unitOfWork.Orders.GetById(orderId);
            var list = new List<OrderItemDTO>();
            foreach (var item in order.Items)
            {
                list.Add(new OrderItemDTO()
                {
                    Name = item.Product.Name
                    ,
                    Price = item.Product.Price
                    ,
                    Amount = item.Amount,
                    ProductId = item.ProductId
                });
            }
            return list;
        }

        public async Task<List<ProductDTO>> GetFilteredProducts(int? Price, string? Color, string? Brand, double? Reach, double? MaxSpeed, int? CarryingCapacity)
        {
            var products = await _unitOfWork.Products.GetAll();
            var filteredProducts = products.Where(p => 
                (Price == null ||  p.Price < Price) &&
                (Color == null || p.Color == Color) &&
                (Brand == null || p.Brand == Brand) &&
                (Reach == null || p.Reach >= Reach) &&
                (MaxSpeed == null || p.MaxSpeed >=  MaxSpeed) && 
                (CarryingCapacity == null || p.CarryingCapacity == CarryingCapacity)).ToList();
            return _mapper.Map<List<ProductDTO>>(filteredProducts);
        }
    }
}
