﻿using AutoMapper;
using eStore.DTOs;
using eStore.Models;
using BC = BCrypt.Net;

namespace eStore.MapperConfig
{
    public class MapperProfile : Profile
    {
        public MapperProfile()
        {
            CreateMap<RegisterDTO, User>().ForMember(dest => dest.Password, opt => opt.MapFrom(dto => BC.BCrypt.HashPassword(dto.Password)));
            CreateMap<User, RegisterDTO>();
            //CreateMap<User, UserDTO>().ReverseMap();
            //CreateMap<User, EditProfileDTO>().ReverseMap();
            CreateMap<User, SellerDTO>().ReverseMap();

            CreateMap<Order, CreateOrderDTO>().ReverseMap();
            CreateMap<Order, OrderDTO>()
                .ForMember(dest => dest.DeliveryAddress
                ,opt => opt.MapFrom(order => order.Buyer.Address));
            CreateMap<OrderDTO, Order>();

            CreateMap<OrderItem, OrderItemDTO>().ReverseMap();
            CreateMap<OrderItem, CreateOrderItemDTO>().ReverseMap();

            CreateMap<Product, CreateProductDTO>().ReverseMap();
            CreateMap<Product, ProductDTO>().ReverseMap();

            CreateMap<User, UserDTO>().ReverseMap();
            CreateMap<User, ChangeProfileDTO>().ReverseMap();
        }
    }
}
